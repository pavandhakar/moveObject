//
//  ViewController.h
//  MoveObject
//
//  Created by pavan on 10/27/17.
//  Copyright © 2017 Pavan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIImageView *Switch3Way;

@end

